/**
 * เพิ่มข้อมูลตัวอย่างสมมติสำหรับดู Dashboard เท่านั้น
 * รัน setupSystem_ ก่อน แล้วเลือก seedMockData จากเมนู Run
 * ฟังก์ชันนี้ทำซ้ำได้โดยไม่เพิ่มข้อมูล MOCK ชุดเดิม
 */
function seedMockData() {
  const year = Number(Utilities.formatDate(new Date(), 'Asia/Bangkok', 'yyyy')) + 543;
  const places = [
    {province:'แม่ฮ่องสอน', district:'เมืองแม่ฮ่องสอน', subdistrict:'ห้วยโป่ง', coffeeType:'อะราบิกา'},
    {province:'แม่ฮ่องสอน', district:'ปาย', subdistrict:'เวียงเหนือ', coffeeType:'อะราบิกา'},
    {province:'แม่ฮ่องสอน', district:'แม่ลาน้อย', subdistrict:'แม่ลาน้อย', coffeeType:'อะราบิกา'},
    {province:'เชียงใหม่', district:'แม่แตง', subdistrict:'กื้ดช้าง', coffeeType:'อะราบิกา'},
    {province:'เชียงราย', district:'แม่สรวย', subdistrict:'วาวี', coffeeType:'อะราบิกา'},
    {province:'ชุมพร', district:'ท่าแซะ', subdistrict:'รับร่อ', coffeeType:'โรบัสต้า'}
  ];
  const registrations = rows_('REGISTRATIONS', APP_SCHEMA.registerHeaders);
  places.forEach((p, i) => {
    const entityId = 'MOCK-' + String(i + 1).padStart(3, '0');
    if (!registrations.some(r => r.entityId === entityId)) append_('REGISTRATIONS', APP_SCHEMA.registerHeaders, {
      entityId, requestId:'mock-registration-' + (i + 1), createdAt:new Date().toISOString(), commodity:APP_SCHEMA.commodity,
      entityName:'กิจการตัวอย่าง ' + p.district, entityType:i < 3 ? 'เกษตรกร' : i < 5 ? 'ผู้แปรรูป' : 'ผู้จำหน่าย',
      province:p.province, district:p.district, subdistrict:p.subdistrict, phone:'', consent:true
    });
  });
  APP_SCHEMA.categories.forEach((category, categoryIndex) => {
    const headers = APP_SCHEMA.common.concat(category.fields.map(f => f.key));
    const existing = rows_(category.sheet, headers);
    places.forEach((p, i) => {
      const requestId = 'mock-' + category.id + '-' + (i + 1);
      if (existing.some(r => r.requestId === requestId)) return;
      const row = {recordId:Utilities.getUuid(), requestId, createdAt:new Date().toISOString(),
        entityId:'MOCK-' + String(i + 1).padStart(3, '0'), commodity:APP_SCHEMA.commodity, reportYear:year,
        province:p.province, coffeeType:p.coffeeType, productForm:'สารกาแฟ (เมล็ดดิบ)', recordKey:'รายการตัวอย่าง ' + (i + 1)};
      category.fields.forEach((field, fieldIndex) => row[field.key] = mockFieldValue_(field, p, i, categoryIndex, year, fieldIndex));
      append_(category.sheet, headers, row);
    });
  });
  const market = rows_('DEMAND_SUPPLY', APP_SCHEMA.marketHeaders);
  places.forEach((p, i) => ['Supply','Demand'].forEach((direction, d) => {
    const requestId = 'mock-market-' + (i + 1) + '-' + direction.toLowerCase();
    if (market.some(r => r.requestId === requestId)) return;
    append_('DEMAND_SUPPLY', APP_SCHEMA.marketHeaders, {
      recordId:Utilities.getUuid(), requestId, createdAt:new Date().toISOString(), entityId:'MOCK-' + String(i + 1).padStart(3, '0'),
      commodity:APP_SCHEMA.commodity, reportYear:year, province:p.province, coffeeType:p.coffeeType,
      productForm:'สารกาแฟ (เมล็ดดิบ)', recordKey:'ANNUAL', stage:i < 3 ? 'ต้นน้ำ' : i < 5 ? 'กลางน้ำ' : 'ปลายน้ำ',
      direction, quantityKg:(i + 3) * 4200 + (d ? 1800 - i * 300 : 0), priceBahtKg:direction === 'Supply' ? 145 + i * 5 : 165 + i * 4,
      notes:'ข้อมูลสมมติสำหรับทดสอบ Dashboard ห้ามใช้อ้างอิง'
    });
  }));
  return {status:'ok', message:'เพิ่มข้อมูลตัวอย่างสมมติแล้ว', year, entities:places.length};
}

function mockFieldValue_(field, place, index, categoryIndex, year, fieldIndex) {
  const label = field.label;
  if (label.includes('หมายเหตุ')) return 'ข้อมูลสมมติสำหรับทดสอบ Dashboard';
  if (label.includes('จังหวัด')) return place.province;
  if (label.includes('อำเภอ')) return place.district;
  if (label.includes('ตำบล')) return place.subdistrict;
  if (label.includes('หมู่บ้าน')) return 'บ้านตัวอย่าง ' + (index + 1);
  if (label.includes('ชนิดกาแฟ')) return place.coffeeType;
  if (label.includes('ปีงบประมาณ')) return year;
  if (label.includes('พื้นที่ปลูก')) return 12 + index * 4;
  if (label.includes('ผลผลิต (กก./ปี)')) return 1100 + index * 380;
  if (label.includes('สัดส่วน') && label.includes('%')) return 65 + index * 5;
  if (field.type === 'number') return (index + 2) * (fieldIndex + 3) * 10;
  if (field.type === 'select') return field.options && field.options[0] || '';
  return (field.required ? 'รายการตัวอย่าง' : 'ข้อมูลตัวอย่าง') + ' ' + (categoryIndex + 1) + '-' + (index + 1);
}
