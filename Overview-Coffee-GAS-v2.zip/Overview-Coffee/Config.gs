const APP_SCHEMA = {
  "title": "Overview - Coffee",
  "commodity": "coffee",
  "coffeeTypes": [
    "อะราบิกา",
    "โรบัสต้า",
    "อื่น ๆ"
  ],
  "productForms": [
    "ผลสด (เชอร์รี)",
    "กะลา",
    "สารกาแฟ (เมล็ดดิบ)",
    "เมล็ดคั่ว",
    "กาแฟบด"
  ],
  "stages": [
    "ต้นน้ำ",
    "กลางน้ำ",
    "ปลายน้ำ"
  ],
  "categories": [
    {
      "id": "c1",
      "sheet": "01_โครงการส่งเสริม",
      "label": "โครงการส่งเสริม",
      "stage": "ต้นน้ำ",
      "fields": [
        {
          "key": "f1",
          "label": "หน่วยงาน",
          "type": "text",
          "options": null,
          "required": true,
          "max": null
        },
        {
          "key": "f2",
          "label": "ชื่อโครงการ/กิจกรรม",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f3",
          "label": "งบประมาณ (บาท)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f4",
          "label": "แหล่งที่มาของเงิน",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f5",
          "label": "ปีงบประมาณ",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f6",
          "label": "อำเภอ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f7",
          "label": "ตำบล",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f8",
          "label": "หมู่บ้าน",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f9",
          "label": "จำนวนกลุ่มเป้าหมาย (ราย/กลุ่ม)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f10",
          "label": "ชนิดกาแฟ",
          "type": "select",
          "options": [
            "อะราบิกา",
            "โรบัสต้า",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f11",
          "label": "สายพันธุ์",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f12",
          "label": "พื้นที่ส่งเสริม (ไร่)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f13",
          "label": "มาตรฐานการผลิต",
          "type": "select",
          "options": [
            "GAP",
            "อินทรีย์",
            "GI",
            "ไม่ได้รับ",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f14",
          "label": "ต้นทุนการผลิต (บาท/ไร่)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f15",
          "label": "หมายเหตุ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        }
      ]
    },
    {
      "id": "c2",
      "sheet": "02_ข้อมูลเกษตรกร",
      "label": "ข้อมูลเกษตรกร",
      "stage": "ต้นน้ำ",
      "fields": [
        {
          "key": "f1",
          "label": "ชื่อ-สกุล/รหัสเกษตรกร",
          "type": "text",
          "options": null,
          "required": true,
          "max": null
        },
        {
          "key": "f2",
          "label": "อำเภอ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f3",
          "label": "ตำบล",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f4",
          "label": "หมู่บ้าน",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f5",
          "label": "ระดับความสูง (ม.รทก.)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f6",
          "label": "พื้นที่ปลูก (ไร่)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f7",
          "label": "ชนิดกาแฟ",
          "type": "select",
          "options": [
            "อะราบิกา",
            "โรบัสต้า",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f8",
          "label": "สายพันธุ์",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f9",
          "label": "อายุเฉลี่ยต้นกาแฟ (ปี)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f10",
          "label": "รูปแบบการปลูก",
          "type": "select",
          "options": [
            "เชิงเดี่ยว",
            "ร่วมกับไม้ผล",
            "ใต้ร่มเงา/วนเกษตร",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f11",
          "label": "ผลผลิต (กก./ปี)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f12",
          "label": "มาตรฐานการปลูก",
          "type": "select",
          "options": [
            "GAP",
            "อินทรีย์",
            "GI",
            "ไม่ได้รับ",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f13",
          "label": "ราคาจำหน่ายเฉลี่ย (บาท/กก.)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f14",
          "label": "ระยะห่างจากถนน (กม.)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f15",
          "label": "ชนิดถนน",
          "type": "select",
          "options": [
            "ลาดยาง/คอนกรีต",
            "ลูกรัง",
            "ดิน",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f16",
          "label": "ประเภทแหล่งน้ำ",
          "type": "select",
          "options": [
            "น้ำฝน",
            "ประปาภูเขา",
            "ลำห้วย/แหล่งน้ำธรรมชาติ",
            "บ่อ/สระ",
            "ระบบชลประทาน",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f17",
          "label": "หมายเหตุ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        }
      ]
    },
    {
      "id": "c3",
      "sheet": "03_สถาบันเกษตรกร",
      "label": "สถาบันเกษตรกร",
      "stage": "ต้นน้ำ",
      "fields": [
        {
          "key": "f1",
          "label": "ชื่อสถาบันเกษตรกร",
          "type": "text",
          "options": null,
          "required": true,
          "max": null
        },
        {
          "key": "f2",
          "label": "ประเภทสถาบัน",
          "type": "select",
          "options": [
            "กลุ่มเกษตรกร",
            "วิสาหกิจชุมชน",
            "แปลงใหญ่",
            "สหกรณ์",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f3",
          "label": "อำเภอ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f4",
          "label": "ตำบล",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f5",
          "label": "หมู่บ้าน",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f6",
          "label": "จำนวนสมาชิก (ราย)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f7",
          "label": "มาตรฐานที่ได้รับ",
          "type": "select",
          "options": [
            "GAP",
            "อินทรีย์",
            "GI",
            "ไม่ได้รับ",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f8",
          "label": "กิจกรรมที่ดำเนินการ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f9",
          "label": "ปริมาณรับซื้อ (กก./ปี)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f10",
          "label": "ราคารับซื้อเฉลี่ย (บาท/กก.)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f11",
          "label": "ปริมาณจำหน่าย (กก./ปี)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f12",
          "label": "ราคาจำหน่ายเฉลี่ย (บาท/กก.)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f13",
          "label": "หมายเหตุ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        }
      ]
    },
    {
      "id": "c4",
      "sheet": "04_การรวบรวม",
      "label": "การรวบรวม",
      "stage": "กลางน้ำ",
      "fields": [
        {
          "key": "f1",
          "label": "หน่วยงาน/องค์กร",
          "type": "text",
          "options": null,
          "required": true,
          "max": null
        },
        {
          "key": "f2",
          "label": "โครงการ/กิจกรรม",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f3",
          "label": "งบประมาณ (บาท)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f4",
          "label": "แหล่งที่มาของเงิน",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f5",
          "label": "ปีงบประมาณ",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f6",
          "label": "อำเภอ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f7",
          "label": "ตำบล",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f8",
          "label": "หมู่บ้าน",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f9",
          "label": "ชนิดกาแฟ",
          "type": "select",
          "options": [
            "อะราบิกา",
            "โรบัสต้า",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f10",
          "label": "สายพันธุ์",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f11",
          "label": "ปริมาณรวบรวม (กก./ปี)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f12",
          "label": "ราคารับซื้อจากเกษตรกร (บาท/กก.)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f13",
          "label": "กิจกรรมที่ดำเนินการ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f14",
          "label": "มาตรฐานที่ได้รับ",
          "type": "select",
          "options": [
            "GAP",
            "อินทรีย์",
            "GI",
            "ไม่ได้รับ",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f15",
          "label": "ผลผลิตที่ได้",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f16",
          "label": "ปริมาณผลผลิต (กก./ปี)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f17",
          "label": "ราคาจำหน่ายต่อหน่วย (บาท)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f18",
          "label": "หมายเหตุ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        }
      ]
    },
    {
      "id": "c5",
      "sheet": "05_การแปรรูป",
      "label": "การแปรรูป",
      "stage": "กลางน้ำ",
      "fields": [
        {
          "key": "f1",
          "label": "ชื่อสถานประกอบการ",
          "type": "text",
          "options": null,
          "required": true,
          "max": null
        },
        {
          "key": "f2",
          "label": "ประเภทสถานประกอบการ",
          "type": "select",
          "options": [
            "เอกชน",
            "สหกรณ์",
            "มูลนิธิ",
            "วิสาหกิจชุมชน",
            "กลุ่มเกษตรกร",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f3",
          "label": "อำเภอ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f4",
          "label": "ตำบล",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f5",
          "label": "หมู่บ้าน",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f6",
          "label": "สายพันธุ์ที่รับซื้อ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f7",
          "label": "ปริมาณรับซื้อ (กก./ปี)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f8",
          "label": "ราคารับซื้อเฉลี่ย (บาท/กก.)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f9",
          "label": "กิจกรรมการแปรรูป",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f10",
          "label": "ประเภทผลผลิตแปรรูป",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f11",
          "label": "ปริมาณผลผลิตแปรรูป (กก./ปี)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f12",
          "label": "ราคาจำหน่ายต่อหน่วย (บาท)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f13",
          "label": "ช่องทางการจำหน่าย",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f14",
          "label": "มาตรฐานที่ได้รับ",
          "type": "select",
          "options": [
            "GAP",
            "อินทรีย์",
            "GI",
            "ไม่ได้รับ",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f15",
          "label": "หมายเหตุ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        }
      ]
    },
    {
      "id": "c6",
      "sheet": "06_จำหน่ายเมล็ดกาแฟ",
      "label": "จำหน่ายเมล็ดกาแฟ",
      "stage": "ปลายน้ำ",
      "fields": [
        {
          "key": "f1",
          "label": "หน่วยงาน/องค์กร/ผู้ประกอบการ",
          "type": "text",
          "options": null,
          "required": true,
          "max": null
        },
        {
          "key": "f2",
          "label": "อำเภอ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f3",
          "label": "ตำบล",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f4",
          "label": "หมู่บ้าน",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f5",
          "label": "ประเภทสินค้ากาแฟที่จำหน่าย",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f6",
          "label": "ชนิดกาแฟ",
          "type": "select",
          "options": [
            "อะราบิกา",
            "โรบัสต้า",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f7",
          "label": "สายพันธุ์",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f8",
          "label": "ปริมาณจำหน่าย (กก./ปี)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f9",
          "label": "ราคาจำหน่ายเฉลี่ย (บาท/กก.)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f10",
          "label": "ช่องทางการจำหน่าย",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f11",
          "label": "ตลาดหลัก/พื้นที่จำหน่าย",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f12",
          "label": "หมายเหตุ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        }
      ]
    },
    {
      "id": "c7",
      "sheet": "07_ร้านกาแฟ",
      "label": "ร้านกาแฟ",
      "stage": "ปลายน้ำ",
      "fields": [
        {
          "key": "f1",
          "label": "ชื่อร้าน",
          "type": "text",
          "options": null,
          "required": true,
          "max": null
        },
        {
          "key": "f2",
          "label": "ประเภทร้าน",
          "type": "select",
          "options": [
            "โรงคั่วที่จำหน่ายกาแฟ",
            "ร้านกาแฟ (คาเฟ่)",
            "ร้านอาหารที่จำหน่ายกาแฟ",
            "โรงแรม",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f3",
          "label": "อำเภอ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f4",
          "label": "ตำบล",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f5",
          "label": "หมู่บ้าน",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f6",
          "label": "แหล่งซื้อกาแฟ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f7",
          "label": "ชนิดกาแฟที่ใช้",
          "type": "select",
          "options": [
            "อะราบิกา",
            "โรบัสต้า",
            "อื่น ๆ"
          ],
          "required": false,
          "max": null
        },
        {
          "key": "f8",
          "label": "ปริมาณใช้เมล็ดกาแฟ (กก./ปี)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f9",
          "label": "ปริมาณจำหน่าย (แก้ว/ปี)",
          "type": "number",
          "options": null,
          "required": false,
          "max": null
        },
        {
          "key": "f10",
          "label": "สัดส่วนกาแฟเชียงใหม่ที่ใช้ (%)",
          "type": "number",
          "options": null,
          "required": false,
          "max": 100
        },
        {
          "key": "f11",
          "label": "หมายเหตุ",
          "type": "text",
          "options": null,
          "required": false,
          "max": null
        }
      ]
    }
  ],
  "common": [
    "recordId",
    "requestId",
    "createdAt",
    "entityId",
    "commodity",
    "reportYear",
    "province",
    "coffeeType",
    "productForm",
    "recordKey"
  ],
  "registerHeaders": [
    "entityId",
    "requestId",
    "createdAt",
    "commodity",
    "entityName",
    "entityType",
    "province",
    "district",
    "subdistrict",
    "phone",
    "consent"
  ],
  "marketHeaders": [
    "recordId",
    "requestId",
    "createdAt",
    "entityId",
    "commodity",
    "reportYear",
    "province",
    "coffeeType",
    "productForm",
    "recordKey",
    "stage",
    "direction",
    "quantityKg",
    "priceBahtKg",
    "notes"
  ]
};
const APP_SPREADSHEET_ID = "1p6gUgQuvVPRVZipJihtkCDZNBK3h9_RUkBAHvmJbZ6w";
