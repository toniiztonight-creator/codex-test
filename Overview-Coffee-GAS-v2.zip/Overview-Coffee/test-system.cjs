const fs=require('fs'),vm=require('vm'),assert=require('node:assert/strict'),crypto=require('crypto');
const path=require('path'),base=__dirname,schema=JSON.parse(fs.readFileSync(path.join(base,'schema.json')));
const specs=[['REGISTRATIONS',schema.registerHeaders],['DEMAND_SUPPLY',schema.marketHeaders],...schema.categories.map(c=>[c.sheet,schema.common.concat(c.fields.map(f=>f.key))])];
const tables=Object.fromEntries(specs.map(([name,headers])=>[name,[headers]]));
function sheet(name){return {getName:()=>name,getLastRow:()=>tables[name].length,
 getRange:(row,col,rc,cc)=>({getValues:()=>tables[name].slice(row-1,row-1+rc).map(r=>r.slice(col-1,col-1+cc))}),
 appendRow:r=>tables[name].push(r)};}
const context={console,Set,Date,Object,JSON,Number,String,Math,Array,
 SpreadsheetApp:{openById:()=>({getSheetByName:sheet}),flush:()=>{}},
 PropertiesService:{getScriptProperties:()=>({getProperty:()=> 'secret-test-pin'})},
 Utilities:{getUuid:()=>crypto.randomUUID()},LockService:{getScriptLock:()=>({waitLock:()=>{},releaseLock:()=>{}})}};
vm.createContext(context);
for(const name of ['Config.gs','Code.gs','Dashboard.gs'])vm.runInContext(fs.readFileSync(path.join(base,name),'utf8'),context,{filename:name});
let count=0;function test(label,fn){fn();count++;console.log('PASS '+label);}
const pin='secret-test-pin';let id;
const reg={pin,requestId:'register-request-001',entityName:'ผู้ให้ข้อมูลทดสอบ',entityType:'เกษตรกร',province:'เชียงใหม่',district:'เมือง',consent:true};
test('Registration stores participant and returns an ID',()=>{id=context.registerEntity(reg).entityId;assert.match(id,/^CF-/);assert.equal(tables.REGISTRATIONS.length,2);});
test('Transport retry is idempotent',()=>{assert.equal(context.registerEntity(reg).entityId,id);assert.equal(tables.REGISTRATIONS.length,2);});
test('Duplicate registration rejected',()=>assert.throws(()=>context.registerEntity({...reg,requestId:'register-request-002'}),/มีผู้ให้ข้อมูล/));
test('Bad PIN rejected',()=>assert.throws(()=>context.registerEntity({...reg,pin:'wrong'}),/รหัส/));
test('Consent required',()=>assert.throws(()=>context.registerEntity({...reg,consent:false}),/ยืนยัน/));
const baseRecord={pin,entityId:id,province:'เชียงใหม่',reportYear:2569,coffeeType:'อะราบิกา',productForm:'สารกาแฟ (เมล็ดดิบ)',recordKey:'แปลง A'};
const c=schema.categories.find(x=>x.id==='c2');
const key=label=>c.fields.find(f=>f.label===label).key;
let farmer={...baseRecord,categoryId:'c2',requestId:'farmer-request-001',fields:{[c.fields[0].key]:'เกษตรกรทดสอบ',[key('พื้นที่ปลูก (ไร่)')]:10,[key('ผลผลิต (กก./ปี)')]:1000,[key('หมายเหตุ')]:'=HYPERLINK("bad")'}};
test('Farmer row writes all fields and formula text is escaped',()=>{context.saveRecord(farmer);assert.equal(tables[c.sheet].length,2);assert.ok(tables[c.sheet][1].at(-1).startsWith("'="));});
test('Duplicate farmer plot across product forms is rejected',()=>assert.throws(()=>context.saveRecord({...farmer,requestId:'farmer-request-002',productForm:'ผลสด (เชอร์รี)'}),/มีแล้ว/));
test('Unknown entity rejected',()=>assert.throws(()=>context.saveRecord({...farmer,requestId:'farmer-request-003',entityId:'UNKNOWN'}),/ไม่พบรหัส/));
test('Negative quantities rejected',()=>assert.throws(()=>context.saveRecord({...farmer,fields:{...farmer.fields,[key('ผลผลิต (กก./ปี)')]:-1}}),/ไม่ติดลบ/));
test('Calendar year validation rejects CE and noninteger',()=>{assert.throws(()=>context.saveRecord({...farmer,reportYear:2026}),/พ.ศ./);assert.throws(()=>context.saveRecord({...farmer,reportYear:2569.5}),/พ.ศ./);});
let market={...baseRecord,requestId:'market-request-001',stage:'ต้นน้ำ',direction:'Supply',quantityKg:800,priceBahtKg:100};
test('Annual supply declaration writes once',()=>{context.saveMarket(market);context.saveMarket(market);assert.equal(tables.DEMAND_SUPPLY.length,2);});
test('Same supply cannot be counted in a second chain stage',()=>assert.throws(()=>context.saveMarket({...market,requestId:'market-request-002',stage:'กลางน้ำ',recordKey:'another site'}),/มียอดรวม/));
test('Demand writes in separate direction',()=>context.saveMarket({...market,requestId:'market-demand-001',direction:'Demand',quantityKg:500}));
test('Zero differs from missing side',()=>{context.saveMarket({...market,requestId:'market-robusta-001',coffeeType:'โรบัสต้า',quantityKg:0});const d=context.getDashboard({reportYear:2569});const r=d.marketGroups.find(x=>x.coffeeType==='โรบัสต้า');assert.equal(r.supply,0);assert.equal(r.demand,null);assert.equal(r.gap,null);});
test('Dashboard aggregates correct metrics without raw personal data',()=>{const d=context.getDashboard({reportYear:2569,coffeeType:'อะราบิกา',productForm:baseRecord.productForm});assert.equal(d.area,10);assert.equal(d.production,1000);assert.equal(d.marketGroups[0].gap,300);assert.equal(d.entities,1);assert.ok(!JSON.stringify(d).includes(id));assert.ok(!JSON.stringify(d).includes(reg.entityName));});
test('Year filter isolates reporting periods',()=>{const d=context.getDashboard({reportYear:2570});assert.equal(d.totalRecords,0);assert.equal(d.area,null);assert.equal(d.marketGroups.length,0);});
test('Mixed-form production is not summed',()=>assert.equal(context.getDashboard({reportYear:2569}).production,null));
test('Each of 7 category forms saves with the supplied schema',()=>{for(const cat of schema.categories.filter(x=>x.id!=='c2')){context.saveRecord({...baseRecord,categoryId:cat.id,recordKey:'กิจกรรม '+cat.id,requestId:'category-request-'+cat.id,fields:{[cat.fields[0].key]:'รายการทดสอบ'}});assert.equal(tables[cat.sheet].length,2);}});
test('Cafe percentage greater than 100 is rejected',()=>{const cafe=schema.categories.find(c=>c.id==='c7'),f=cafe.fields.find(x=>x.label.includes('(%)'));assert.throws(()=>context.saveRecord({...baseRecord,categoryId:'c7',requestId:'cafe-percent-001',fields:{[cafe.fields[0].key]:'ร้านทดสอบ',[f.key]:101}}),/ไม่เกิน 100/);});
for(const file of ['Code.gs','Config.gs','Dashboard.gs'])new vm.Script(fs.readFileSync(path.join(base,file),'utf8'));
new vm.Script(fs.readFileSync(path.join(base,'JavaScript.html'),'utf8').replace(/^<script>\s*/,'').replace(/<\/script>\s*$/,''));
console.log(count+' checks passed; Apps Script/browser JS syntax valid.');
fs.writeFileSync(path.join(base,'TEST-RESULTS.txt'),count+' automated checks passed in Node using an Apps Script service mock.\nNot yet deployed or tested against live Apps Script.\n');
