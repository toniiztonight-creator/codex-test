/** Public endpoints return aggregate figures only, never names, phones, entity IDs or raw rows. */
function aggregate_(datasets,market,filter){
  const f=filter||{};
  const matches=r=>['reportYear','province','coffeeType','productForm'].every(k=>!f[k]||String(r[k])===String(f[k]));
  const groups=[],stageCounts={'ต้นน้ำ':0,'กลางน้ำ':0,'ปลายน้ำ':0},provinceCounts={},ids=new Set();
  let area=0,areaKnown=0,production=0,productionKnown=0,farmerRows=0;
  APP_SCHEMA.categories.forEach(c=>{
    const data=(datasets[c.id]||[]).filter(matches).filter(()=>!f.stage||c.stage===f.stage);
    groups.push({label:c.label,stage:c.stage,count:data.length});stageCounts[c.stage]+=data.length;
    data.forEach(r=>{ids.add(r.entityId);provinceCounts[r.province]=(provinceCounts[r.province]||0)+1;});
    if(c.id==='c2'){
      farmerRows=data.length;
      const areaKey=c.fields.find(x=>x.label==='พื้นที่ปลูก (ไร่)').key;
      const productionKey=c.fields.find(x=>x.label==='ผลผลิต (กก./ปี)').key;
      data.forEach(r=>{if(typeof r[areaKey]==='number'){area+=r[areaKey];areaKnown++;}
        if(typeof r[productionKey]==='number'){production+=r[productionKey];productionKnown++;}});
    }
  });
  const m=market.filter(matches).filter(r=>!f.stage||r.stage===f.stage), buckets={};
  m.forEach(r=>{
    if(!APP_SCHEMA.coffeeTypes.includes(r.coffeeType)||!APP_SCHEMA.productForms.includes(r.productForm)||!['Supply','Demand'].includes(r.direction)||typeof r.quantityKg!=='number'||r.quantityKg<0)return;
    const key=JSON.stringify([r.reportYear,r.coffeeType,r.productForm]);
    const b=buckets[key]||(buckets[key]={year:r.reportYear,coffeeType:r.coffeeType,productForm:r.productForm,supply:0,demand:0,supplyCount:0,demandCount:0});
    const d=r.direction.toLowerCase();b[d]+=r.quantityKg;b[d+'Count']++;
  });
  const marketGroups=Object.values(buckets).sort((a,b)=>String(a.coffeeType+a.productForm).localeCompare(b.coffeeType+b.productForm,'th')).map(b=>{
    b.supply=b.supplyCount?b.supply:null;b.demand=b.demandCount?b.demand:null;
    b.gap=b.supply!==null&&b.demand!==null?b.supply-b.demand:null;return b;
  });
  const mockRecords=Object.values(datasets).flat().filter(r=>String(r.entityId).startsWith('MOCK-')).length+
    m.filter(r=>String(r.entityId).startsWith('MOCK-')).length;
  return {groups,stageCounts,provinceCounts,entities:ids.size,totalRecords:groups.reduce((s,x)=>s+x.count,0),mockRecords,
    farmerRows,area:areaKnown?area:null,areaKnown,production:f.productForm&&productionKnown?production:null,productionKnown,
    marketGroups,marketRecords:m.length,updatedAt:new Date().toISOString()};
}
function getDashboard(filter){
  if(filter&&filter.reportYear)year_(filter.reportYear);
  const datasets={};APP_SCHEMA.categories.forEach(c=>datasets[c.id]=rows_(c.sheet,APP_SCHEMA.common.concat(c.fields.map(x=>x.key))));
  const market=rows_('DEMAND_SUPPLY',APP_SCHEMA.marketHeaders);
  const result=aggregate_(datasets,market,filter);
  const all=Object.values(datasets).flat().concat(market);
  result.provinces=[...new Set(all.map(r=>r.province).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'th'));
  result.years=[...new Set(all.map(r=>r.reportYear).filter(Boolean))].sort((a,b)=>b-a);
  return result;
}
