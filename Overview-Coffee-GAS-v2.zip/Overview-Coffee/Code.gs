/** Entry point: install as a bound script in the supplied Google Sheet. */
function doGet() {
  return HtmlService.createTemplateFromFile('index').evaluate()
    .setTitle(APP_SCHEMA.title).addMetaTag('viewport','width=device-width, initial-scale=1');
}
function include_(file) { return HtmlService.createHtmlOutputFromFile(file).getContent(); }
function getBootstrap() {
  return {schema:APP_SCHEMA, year:Number(Utilities.formatDate(new Date(),'Asia/Bangkok','yyyy'))+543,
    ready:Boolean(PropertiesService.getScriptProperties().getProperty('COLLECTION_PIN'))};
}
/** Run once from the editor. Never resets or deletes existing rows. */
function setupSystem_() {
  const ss=SpreadsheetApp.openById(APP_SPREADSHEET_ID);
  const specs=[['REGISTRATIONS',APP_SCHEMA.registerHeaders],['DEMAND_SUPPLY',APP_SCHEMA.marketHeaders]]
    .concat(APP_SCHEMA.categories.map(c=>[c.sheet,APP_SCHEMA.common.concat(c.fields.map(f=>f.key))]));
  specs.forEach(([name,headers])=>{
    const s=ss.getSheetByName(name)||ss.insertSheet(name);
    if(s.getLastRow()===0)s.getRange(1,1,1,headers.length).setValues([headers]);
    assertHeaders_(s,headers);
    s.setFrozenRows(1);
    s.getRange(1,1,1,headers.length).setFontWeight('bold').setBackground('#eeeeee').setWrap(true);
    s.setRowHeight(1,48);
  });
  const p=PropertiesService.getScriptProperties();
  if(!p.getProperty('COLLECTION_PIN')) p.setProperty('COLLECTION_PIN',Utilities.getUuid().replace(/-/g,'').slice(0,16));
  console.log('Database: '+ss.getUrl());
  console.log('Collection PIN (share with authorized data collectors only): '+p.getProperty('COLLECTION_PIN'));
  console.log('Deployment URL: '+(ScriptApp.getService().getUrl()||'ยังไม่ Deploy'));
}
/** Public editor entry point because Apps Script hides names ending in underscore from the Run menu. */
function runSetup() { return setupSystem_(); }
function db_(){return SpreadsheetApp.openById(APP_SPREADSHEET_ID);}
function assertHeaders_(s,headers){
  if(JSON.stringify(s.getRange(1,1,1,headers.length).getValues()[0])!==JSON.stringify(headers))
    throw new Error('หัวตารางไม่ตรงโครงสร้าง: '+s.getName()+' กรุณาตรวจ DATA_DICTIONARY');
}
function rows_(name,headers){
  const s=db_().getSheetByName(name);
  if(!s)throw new Error('ยังไม่ได้ตั้งค่าระบบ กรุณารัน setupSystem_');
  assertHeaders_(s,headers);
  if(s.getLastRow()<2)return [];
  return s.getRange(2,1,s.getLastRow()-1,headers.length).getValues().filter(r=>r[0])
    .map(r=>Object.fromEntries(headers.map((h,i)=>[h,r[i]])));
}
function text_(v,label,required,max){
  const s=String(v==null?'':v).trim();
  if(required&&!s)throw new Error('กรุณาระบุ '+label);
  if(s.length>(max||500))throw new Error(label+' ยาวเกินกำหนด');
  return s;
}
function choice_(v,options,label){const s=text_(v,label,true);if(!options.includes(s))throw new Error(label+' ไม่ถูกต้อง');return s;}
function number_(v,label,required,max){
  if(v===''||v==null){if(required)throw new Error('กรุณาระบุ '+label);return '';}
  const n=Number(v);
  if(!Number.isFinite(n)||n<0||(max!=null&&n>max))throw new Error(label+' ต้องเป็นเลขไม่ติดลบ'+(max!=null?' และไม่เกิน '+max:''));
  return n;
}
function requestId_(v){const s=text_(v,'รหัสคำขอ',true,80);if(!/^[a-zA-Z0-9_-]{8,80}$/.test(s))throw new Error('รหัสคำขอไม่ถูกต้อง');return s;}
function year_(v){const n=number_(v,'ปีข้อมูล พ.ศ.',true);if(!Number.isInteger(n)||n<2500||n>2700)throw new Error('ปีข้อมูลต้องเป็น พ.ศ. 2500–2700');return n;}
function authorize_(pin){
  const expected=PropertiesService.getScriptProperties().getProperty('COLLECTION_PIN');
  if(!expected)throw new Error('ยังไม่ได้ตั้งค่า COLLECTION_PIN กรุณารัน setupSystem_');
  if(typeof pin!=='string'||pin!==expected)throw new Error('รหัสสำหรับบันทึกข้อมูลไม่ถูกต้อง');
}
function safeCell_(v){return typeof v==='string'&&/^[=+@\-\t\r\n]/.test(v)?"'"+v:v;}
function append_(sheet,headers,obj){const s=db_().getSheetByName(sheet);assertHeaders_(s,headers);s.appendRow(headers.map(h=>safeCell_(obj[h]==null?'':obj[h])));SpreadsheetApp.flush();}
function locked_(fn){const lock=LockService.getScriptLock();lock.waitLock(30000);try{return fn();}finally{lock.releaseLock();}}
function registerEntity(payload){
  authorize_(payload.pin);
  const rid=requestId_(payload.requestId);
  const r={entityName:text_(payload.entityName,'ชื่อผู้ให้ข้อมูล/กิจการ',true),
    entityType:choice_(payload.entityType,['เกษตรกร','สถาบันเกษตรกร','ผู้รวบรวม','ผู้แปรรูป','ผู้จำหน่าย','ร้านกาแฟ','หน่วยงาน'],'ประเภทผู้ให้ข้อมูล'),
    province:text_(payload.province,'จังหวัด',true,100),district:text_(payload.district,'อำเภอ',true,100),
    subdistrict:text_(payload.subdistrict,'ตำบล',false,100),phone:text_(payload.phone,'โทรศัพท์',false,30)};
  if(payload.consent!==true)throw new Error('กรุณายืนยันการใช้ข้อมูลเพื่อจัดทำภาพรวมกาแฟ');
  return locked_(()=>{
    const existing=rows_('REGISTRATIONS',APP_SCHEMA.registerHeaders);
    const retry=existing.find(x=>x.requestId===rid);if(retry)return {entityId:retry.entityId,replayed:true};
    if(existing.some(x=>x.entityName===r.entityName&&x.entityType===r.entityType&&x.province===r.province&&x.district===r.district))
      throw new Error('มีผู้ให้ข้อมูลนี้แล้ว กรุณาใช้รหัสเดิม หรือติดต่อผู้ดูแลตรวจสอบในชีต REGISTRATIONS');
    r.entityId='CF-'+Utilities.getUuid().slice(0,8).toUpperCase();r.requestId=rid;r.createdAt=new Date().toISOString();r.commodity=APP_SCHEMA.commodity;r.consent=true;
    append_('REGISTRATIONS',APP_SCHEMA.registerHeaders,r);
    return {entityId:r.entityId,replayed:false};
  });
}
function commonRecord_(payload){
  return {requestId:requestId_(payload.requestId),entityId:text_(payload.entityId,'รหัสผู้ให้ข้อมูล',true,40),commodity:APP_SCHEMA.commodity,
    reportYear:year_(payload.reportYear),province:text_(payload.province,'จังหวัด',true,100),
    coffeeType:choice_(payload.coffeeType,APP_SCHEMA.coffeeTypes,'ชนิดกาแฟ'),
    productForm:choice_(payload.productForm,APP_SCHEMA.productForms,'รูปแบบสินค้า'),
    recordKey:text_(payload.recordKey,'ชื่อแปลง/กิจกรรม/สาขา',true,200)};
}
function verifyEntity_(r){
  const entity=rows_('REGISTRATIONS',APP_SCHEMA.registerHeaders).find(x=>x.entityId===r.entityId);
  if(!entity)throw new Error('ไม่พบรหัสผู้ให้ข้อมูล กรุณาลงทะเบียนก่อน');
  if(entity.province!==r.province)throw new Error('จังหวัดต้องตรงกับข้อมูลลงทะเบียน (กรณีต่างจังหวัดให้ลงทะเบียนแยกสาขา)');
}
function sameBase_(a,b){return ['entityId','commodity','reportYear','province','coffeeType','productForm','recordKey'].every(k=>String(a[k])===String(b[k]));}
function saveRecord(payload){
  authorize_(payload.pin);
  const c=APP_SCHEMA.categories.find(x=>x.id===payload.categoryId);
  if(!c)throw new Error('หมวดข้อมูลไม่ถูกต้อง');
  const r=commonRecord_(payload),fields=payload.fields||{};
  c.fields.forEach(f=>{
    r[f.key]=f.type==='number'?number_(fields[f.key],f.label,f.required,f.max):f.type==='select'?
      (fields[f.key]?choice_(fields[f.key],f.options,f.label):text_('',f.label,f.required)):
      text_(fields[f.key],f.label,f.required,f.label==='หมายเหตุ'?2000:500);
    if(f.label==='ชนิดกาแฟ'||f.label==='ชนิดกาแฟที่ใช้')r[f.key]=r.coffeeType;
    if(f.label==='ปีงบประมาณ'&&r[f.key]!==''&&(!Number.isInteger(r[f.key])||r[f.key]<2500||r[f.key]>2700))throw new Error('ปีงบประมาณต้องเป็น พ.ศ.');
  });
  return locked_(()=>{
    verifyEntity_(r);
    const headers=APP_SCHEMA.common.concat(c.fields.map(f=>f.key)),existing=rows_(c.sheet,headers);
    const retry=existing.find(x=>x.requestId===r.requestId);if(retry)return {recordId:retry.recordId,replayed:true};
    const duplicate=existing.some(x=>c.id==='c2'?
      ['entityId','reportYear','province','recordKey'].every(k=>String(x[k])===String(r[k])):sameBase_(x,r));
    if(duplicate)throw new Error('ข้อมูลรายการนี้มีแล้ว กรุณาตรวจสอบ หรือระบุชื่อแปลง/กิจกรรม/สาขาอื่น (เกษตรกร: หนึ่งแปลงต่อปี กาแฟผสมให้แยกพื้นที่แต่ละชนิด)');
    r.recordId=Utilities.getUuid();r.createdAt=new Date().toISOString();append_(c.sheet,headers,r);
    return {recordId:r.recordId,replayed:false};
  });
}
function saveMarket(payload){
  authorize_(payload.pin);
  const r=commonRecord_(payload);
  r.stage=choice_(payload.stage,APP_SCHEMA.stages,'ช่วงห่วงโซ่');r.direction=choice_(payload.direction,['Supply','Demand'],'ด้านตลาด');
  r.quantityKg=number_(payload.quantityKg,'ปริมาณ กก./ปี',true);r.priceBahtKg=number_(payload.priceBahtKg,'ราคา บาท/กก.',false);
  r.notes=text_(payload.notes,'หมายเหตุ',false,2000);
  // One annual declaration per entity, species, form and direction, across stages/sites.
  // A declaration must already include all sites to prevent multiple-stage double counting.
  r.recordKey='ANNUAL';
  return locked_(()=>{
    verifyEntity_(r);const existing=rows_('DEMAND_SUPPLY',APP_SCHEMA.marketHeaders);
    const retry=existing.find(x=>x.requestId===r.requestId);if(retry)return {recordId:retry.recordId,replayed:true};
    if(existing.some(x=>sameBase_(x,r)&&x.direction===r.direction))throw new Error('มียอดรวมรายปีด้านนี้แล้ว กรุณาให้ผู้ดูแลแก้ไขแถวเดิมในชีต DEMAND_SUPPLY');
    r.recordId=Utilities.getUuid();r.createdAt=new Date().toISOString();append_('DEMAND_SUPPLY',APP_SCHEMA.marketHeaders,r);
    return {recordId:r.recordId,replayed:false};
  });
}
